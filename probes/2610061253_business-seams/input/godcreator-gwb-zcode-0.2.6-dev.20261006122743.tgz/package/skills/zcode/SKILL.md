---
name: zcode
description: 要把任务交给本机的 ZCode（另一个 AI 客户端，走 GLM 额度）去做时读：批量迁移、批量改代码这类能写清范围的任务。讲 zcode.open / create / send / status / archive 怎么用、任务说明怎么写、怎么查询与主动回报结果、做完怎么复查与归档。
---

# 给 ZCode 派任务

`zcode.open` 把 ZCode 窗口切到一个工作区，`zcode.create` 在 ZCode 桌面端新建一条会话发任务，`zcode.send` 在已有会话里接着发，`zcode.status` 读最新一轮做完没有、回答是什么，`zcode.archive` 把用完的会话从侧栏收起来。
会话出现在 ZCode 侧栏里，用户能看着它执行、能在界面上接着聊；侧栏只显示窗口当前工作区的会话。派任务的两条都先把会话切到「完全访问」（改文件、运行命令都不先问人），**发出去就返回，不等做完**。
参数与回执字段用 `search {"prefix":"zcode."}` 看 usage。

## 派一个任务

1. 确认 ZCode 桌面端开着、只开了一个工作区窗口。没开或开了多个，命令会报错，请用户处理
2. 用户要在侧栏里看着它执行的，先 `zcode.open {"workspace":"<目录的绝对路径>"}` 把窗口切到下一步建会话用的同一个目录；
   用户正在 ZCode 里看别的工作区、没说要看的，不切
3. 写任务说明。ZCode 有完全访问权限，说明里写清：
   - 在哪个目录、改哪些文件，哪些不能碰
   - 要先读哪些规矩（目标仓的 `AGENTS.md`、相关说明书 `skill.read`；ZCode 接了 gwb 的 MCP 入口，能自己调命令）
   - 做完怎么算完：要跑的检查命令、交回什么（改了哪些文件、检查输出）
   - 不要提交、不要推送，除非这次就是要它提交
4. `run {"command":"zcode.create","args":{"workspace":"<目录的绝对路径>","prompt":"<任务说明>"}}`，记下回执里的 `taskId`
5. 轮询：`zcode.status {"workspace":"<同上>","task":"<taskId>","waitSeconds":240}`，`roundIsOver` 为 `false` 就再调一次，直到为 `true`。
   `waitSeconds` 最多 240：MCP 客户端等一次调用有上限（Claude Code 是 300 秒），别想着一次等到底；中间可以先去干别的，回头再查
6. 做完了读 `replies` 最后一条，再去复查（下一节）。ZCode 会把工具调用记录也写进回答，一轮看图、读文件多的回答能有几万字，
   回执超过 MCP 单次返回的上限就交不回来：这时带上 `"replyTailChars":20000`，只取回答末尾（收尾的总结在最后）

**完成判据**：`status` 回执 `roundIsOver` 为 `true`、`status` 为 `completed`、`mode` 为 `yolo`；复查通过。

## 接着干

- 同一个会话续上：`zcode.send {"workspace":"<建它时的目录>","task":"<taskId>","prompt":"<接着做什么>"}`，ZCode 记得前面几轮；之后照样用 `status` 轮询
- 上一轮还没做完就 `send`，新指令排在后面，回执 `roundStarted` 可能是 `false`：这时 `status` 读到的还是上一轮，等它做完再查
- `pendingPermissions` 非空：停在等人确认，请用户去 ZCode 界面处理
- `status` 是 `failed` / `error`：读 `replies`，改说明后 `send` 重来

## 复查

ZCode 说「做完了」不算数：自己跑一次它说跑过的检查，`git diff` 看改动是不是在说好的范围里。批量任务至少抽查几项。

## 收尾：归档

复查过、不再接着用的会话：`zcode.archive {"workspace":"<建它时的目录>","task":"<taskId>"}`，从 ZCode 侧栏收起来，记录不删。
还在跑的会话会报错，等 `status` 的 `roundIsOver` 为 `true` 再归档。用户还要在界面上看的，别替用户归档。

## 批量派任务

一项一个会话，可以先把几项都 `create` 出去，再轮流 `status`：同一个 home 的命令共用连接，不同 home 各用自己的连接。命令结束只断开自己的连接，调试端口随 ZCode 退出关闭，不会因为一个 home 完成查询而中断另一个 home。别把几十项塞进一个会话，上下文越拖越长，后面容易乱。

遇到连接断开或请求超时，发送可能已经完成，先核对侧栏或已知会话的 `zcode.status`，不要直接重发任务。


## 给常驻通道主动回报

QQ 与协作站派单在 create / send 中附加可选 `report: {id, callback, server}`：每轮唯一 id、已经登记的接收命令、ZCode 内指向派单 home 的 MCP 服务名。插件生成随机 ticket，保存到本 home 的 gwb-data，并自动把回报约定附到提示词。

执行者在最终答复前经指定服务调用 `zcode.report {ticket,state,text}`。state 为 completed、failed 或 needs_input；text 是给发起人的结果摘要，最多 16000 字符。同票相同结果可重交，不同结果拒绝覆盖。ticket 只用于本轮回报，不写进 QQ、笔记或仓库。

回执 recorded 表示已落盘，accepted 表示接收命令已成功接收；不代表 QQ 已送达或 ZCode 进程已停。接收插件加载时调内部 `zcode.report.replay {callback}` 补交未接收结果，无定时轮询。未带 report 的普通调用保留原有 status 查询方式。

不要把不同 home 的入口混用；无法回报时保留同一 ticket 重试报告，不重复执行工作。桌面端崩溃或未调用 report 时只表示尚未回报，不能宣告完成。
