# 协作站框架

**本页回答**：`collab-site` 是什么、文档在哪。

## 是什么

课题组协作站。项目仓用它在每个成员自己的电脑上启动一个站点，成员在网页上批注、看任务，批注与任务存在项目仓的 `collab/` 目录里，经 git 同步。
仓里两个包：

- 框架包 `@godcreator/collab-site`（`packages/collab-site/`）：Vite 插件 `collab()`（项目的 `vite.config.ts` 只写这一行）、外壳、批注层、页面组件、给 gwb 插件的启动出口，以及记录模块（`collab/` 的文件格式、读出状态、写入规则、校验，与合并检查的命令行 `collab-merge-check`）
- gwb 插件 `@godcreator/gwb-collab`（`plugins/collab/`）：提交、同步、Gitea 一有事件就经实时推送检查、常驻运行站点，把要处理的问题交给网站顶部的提示栏，接收网页上的「交给 AI 处理」

## 文档

`docs-site/` 是文档站：`cd docs-site && pnpm install && pnpm build && pnpm start`，打开 `http://127.0.0.1:4332`。
这份 README 是生成物，正本是 `docs-site/content/docs/outputs/readme.mdx`。
