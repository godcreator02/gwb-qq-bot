# 加入协作站项目与配置

说明书 `collab` 的附件。主文件里的「通用规矩」照做。

## 加入项目

一台电脑做一遍：

1. 项目负责人把这个人加进组织的成员团队，并把他的 Gitea 用户名与显示名写进协作仓的 `collab/people.json`
2. 装 VS Code 与 Git LFS（装完运行一次 `git lfs install`）；gwb 的插件管理里装 `gwb-gitea`、`gwb-collab`、`@cordisjs/plugin-timer`
3. 人自己在 Gitea「设置 → 应用」生成令牌，填进 gwb-gitea 的设置 `token`，权限勾四项：仓库读写、组织读写、工单读、用户读。令牌由人生成、由人填，你不经手
4. 问人项目放在哪个已有目录下，调 `collab.project.clone {url, parent}`：`url` 是组织地址 `https://<主机>/<组织>`，`parent` 是那个目录的绝对路径。回执 `listed` 为 `false` 就让人找项目负责人往 `people.json` 加人；在 VS Code 里直接打开项目文件夹 `projectDir` 就是整个项目，不建工作区文件；中途失败时报错写着做到哪一步、前面的不回退，照原话告诉人
5. 克隆完站点在后台运行，地址在 `collab.projects` 每项的 `site.url`；人要现在看就调 `collab.site.start`

**两种登录各管各的**：插件运行的 git（克隆、自动同步、提交审核、检查、更新别的仓）和 Gitea 接口用 gwb-gitea 的令牌；人和你在终端、VS Code 里运行的 git 用 Windows 凭据管理器，第一次联网时弹窗登录一次。两边要是同一个 Gitea 账号。

## 开始之前：命令报这些错时

- 「没找到 gwb-gitea 的设置」「还没填 Gitea 令牌」：照「加入项目」第 2、3 步。Gitea 回 403：原话里 `required=[…]` 是令牌缺的那一项，让人照第 3 步重新生成
- 令牌的账号和 `collab.person` 不一样：两边各是什么照原话告诉人，不改 `collab.person`。「不在 people.json 里」：让人找项目负责人加
- 协作仓 `origin` 的主人不是组织、或协作仓不在以组织命名的项目文件夹里：让人用 `collab.project.clone` 重新克隆，不自己移动目录

## 项目列表、设置、推送

- `collab.projects` 列出全部项目与状态，只读本机，`watchError` 不空是设置 `projects` 写错了；`collab.project.clone {url, parent}` 克隆一个组织并加进列表；`collab.project.add {repo}` 加一个已经克隆好、设好 `collab.person` 的协作仓；`collab.project.remove {repo}` 移出列表、停掉站点，仓本身不动。组织里新加的仓，检查时自动克隆进项目文件夹
- 设置 `ai-handling`（gwb-collab 分区，用 `settings.set` 改）决定网站上「交给 AI 处理」交给谁：`off`（默认）不交；`zcode` 在 ZCode 里建一条完全访问的会话（要装 gwb-zcode 0.2.3 以上、开着 ZCode），选它之前先告诉人「ZCode 完全访问时改文件、运行命令都不问人」；`claude-terminal` 新开一个 pwsh 窗口，在协作仓里运行 Claude Code
- 设置 `site-window` 决定 `collab.site.start` 用什么打开站点：`chrome-app`（默认）开 Chrome 应用窗口，要装 Chrome；`default-browser` 在系统默认浏览器里开新标签页
- Gitea 上一有 push 或合并请求的事件，NAS 上的 ntfy 就推过来，插件十秒左右检查那个组织的项目；推送每次连上也检查全部项目一次。所以一般不用调 `collab.check {repo?}`（立即检查，不给 `repo` 就检查全部）
- `collab.projects` 顶上的 `push`：`waiting` 是连不上 NAS、正在重连，连上后插件自己检查一次；`off` 带 `error` 照原话处理（gwb-gitea 没装或没启用、`push-url` 写错了）。推送地址是 gwb-gitea 的设置 `push-url`，不用配
- gwb 的「协作站」窗格每个项目一行，只显示要处理几件、几个别的仓和服务器不一样、找我的几条（和网站提示栏的数一样），没有操作按钮。人问是哪几条，照附件 `references/daily.md` 的「看有什么要处理」查

## 项目负责人的管理事务

项目负责人就是协作仓的负责人：Gitea 上协作仓的协作者。`people.json` 不记谁是负责人，只有 `id`（Gitea 用户名）与 `name`（显示名）。

- **加人**：把他加进组织的成员团队，再把 Gitea 用户名与显示名写进 `collab/people.json`，用 `collab.submit` 提交
- **换负责人、加共同负责人**：对那个仓调 `collab.repo.setup`，`leads` 写配完以后的全部负责人，协作者与 `main` 的保护一起改好；换项目负责人就是对协作仓这样做。做法见附件 `references/repos.md` 的「配仓」，Gitea 团队与权限怎么配看文档站「Gitea 权限怎么配」那页（`/docs/gitea`）
- **升框架包**：协作仓 `site/` 装的 `@godcreator/collab-site` 要和 gwb-collab 打包的那一版协议号一样，不一样站点就不启动，`collab.projects` 那个项目的 `site.error` 写着「不配套」和该升到哪条线（现在是 `^0.21.0`）。在 `site/` 里 `pnpm add @godcreator/collab-site@^<那条线>`，再提交审核（这一项只有项目负责人能改）；升之前先看协作仓的工作区：`collab.submit` 会带上 `collab/` 与 `site/` 下所有没提交的改动，有别人正在改、还没提交审核的文件，先等他们提交。报错说框架包比 gwb-collab 新，就让人在插件管理里升级 gwb-collab
- **成员报「执行器没有给结论」**：NAS 上的 Gitea Actions 执行器多半没在运行，告诉人去看执行器；不要在 Gitea 上替执行器合并
