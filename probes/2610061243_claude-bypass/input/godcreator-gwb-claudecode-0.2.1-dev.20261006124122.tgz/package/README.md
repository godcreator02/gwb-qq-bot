# gwb-agents

在同一个仓库开发两个独立的 GWB agent 插件：

| 目录 | 包 | 原生入口 |
| --- | --- | --- |
| `plugins/zcode/` | `@godcreator/gwb-zcode` | ZCode 桌面端：打开工作区、创建、续聊、查询、归档与主动回报 |
| `plugins/claudecode/` | `@godcreator/gwb-claudecode` | Claude Code 原生 CLI：创建、续聊、状态与人工恢复（联调中） |

各插件保留自己的命令、依赖、版本和安装入口。QQ bot 独立于本仓，调用方按自己的业务需求适配原生命令。

## 开发

```powershell
pnpm install
pnpm build
pnpm check
```

单包操作用 `pnpm --filter @godcreator/gwb-zcode build` 或 `pnpm --filter @godcreator/gwb-claudecode check`。
隔离 home 安装：`devkit.dev {"home":"<现场名>","dir":"<本仓绝对路径>","packages":["plugins/zcode","plugins/claudecode"]}`。
包按各自变更独立发布；升版本前读 `gwb-release`。

文档站在 `docs-site/`，单独安装依赖，运行 `pnpm doc:render`、`pnpm doc`；历史实验与轨迹全部保留。
本仓沿用原 ZCode 的 Git 历史；远端目前仍为原 `gwb-zcode` 仓，本地开发目录为 `gwb-agents`。
